@echo off
echo.
echo  Uninstalling Ananke...

set "INSTALL_DIR=%LOCALAPPDATA%\Ananke"

:: Remove files
if exist "%INSTALL_DIR%" (
    rmdir /s /q "%INSTALL_DIR%"
    echo  Files removed.
)

:: Remove from user PATH
for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v PATH 2^>nul') do set "CURRENT_PATH=%%B"
set "NEW_PATH=%CURRENT_PATH:;%INSTALL_DIR%=%"
set "NEW_PATH=%NEW_PATH:%INSTALL_DIR%;=%"
set "NEW_PATH=%NEW_PATH:%INSTALL_DIR%=%"
reg add "HKCU\Environment" /v PATH /t REG_EXPAND_SZ /d "%NEW_PATH%" /f >nul

echo  Removed from PATH.
echo.
echo  Open a new terminal to apply changes.
echo.
pause
