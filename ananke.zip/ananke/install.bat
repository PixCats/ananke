@echo off
setlocal

echo.
echo  Installing Ananke...
echo.

:: Install Python dependencies
echo  Installing dependencies...
pip install -r "%~dp0requirements.txt" --quiet
if %errorlevel% neq 0 (
    echo  [ERROR] pip install failed. Make sure Python is installed.
    pause
    exit /b 1
)

:: Destination — C:\Users\<you>\AppData\Local\Ananke
set "INSTALL_DIR=%LOCALAPPDATA%\Ananke"

:: Create install dir
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

:: Copy files
copy /Y "%~dp0agent.py"    "%INSTALL_DIR%\agent.py"    >nul
copy /Y "%~dp0ananke.bat"  "%INSTALL_DIR%\ananke.bat"  >nul
copy /Y "%~dp0requirements.txt" "%INSTALL_DIR%\requirements.txt" >nul

echo  Files copied to %INSTALL_DIR%

:: Check if already on PATH
echo %PATH% | findstr /I /C:"%INSTALL_DIR%" >nul
if %errorlevel% equ 0 (
    echo  Already on PATH, skipping...
    goto done
)

:: Add to user PATH permanently via registry
for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v PATH 2^>nul') do set "CURRENT_PATH=%%B"

if "%CURRENT_PATH%"=="" (
    set "NEW_PATH=%INSTALL_DIR%"
) else (
    set "NEW_PATH=%CURRENT_PATH%;%INSTALL_DIR%"
)

reg add "HKCU\Environment" /v PATH /t REG_EXPAND_SZ /d "%NEW_PATH%" /f >nul

:: Broadcast the change so current explorer sessions pick it up
powershell -Command "[System.Environment]::SetEnvironmentVariable('PATH', [System.Environment]::GetEnvironmentVariable('PATH','User'), 'User')" >nul 2>&1

:done
echo.
echo  ============================================
echo   Ananke installed successfully!
echo   Open a NEW command prompt and type:
echo.
echo     ananke
echo.
echo   to wake her up.
echo  ============================================
echo.
pause
