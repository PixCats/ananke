#!/usr/bin/env python3
"""
Ollama Coding Agent — a local Codex-style agent that runs in your project directory.
"""

import os
import sys
import json
import subprocess
import requests
import textwrap
from pathlib import Path

# ── CONFIG ───────────────────────────────────────────────────────────────────
OLLAMA_BASE   = "http://localhost:11434"
PROJECT_DIR   = Path.cwd()
MAX_FILE_SIZE = 32_000   # chars — skip huge files when reading
IGNORE_DIRS   = {".git", "__pycache__", "node_modules", ".venv", "venv", ".env",
                 "dist", "build", ".idea", ".vscode"}
IGNORE_EXTS   = {".pyc", ".pyo", ".exe", ".dll", ".so", ".bin", ".jpg", ".jpeg",
                 ".png", ".gif", ".ico", ".svg", ".mp4", ".mp3", ".zip", ".tar",
                 ".gz", ".lock", ".sum"}

# ANSI colours
R  = "\033[91m"   # red
G  = "\033[92m"   # green
Y  = "\033[93m"   # yellow
B  = "\033[94m"   # blue
M  = "\033[95m"   # magenta
C  = "\033[96m"   # cyan
W  = "\033[97m"   # white
DIM= "\033[2m"
RST= "\033[0m"
BOLD="\033[1m"


# ── HELPERS ──────────────────────────────────────────────────────────────────
def clear(): os.system("cls" if os.name == "nt" else "clear")

def banner():
    print(f"""
{B}{BOLD}╔══════════════════════════════════════════╗
║        Ollama Coding Agent  v1.0         ║
╚══════════════════════════════════════════╝{RST}
{DIM}Project: {PROJECT_DIR}{RST}
""")

def hr(char="─", color=DIM):
    width = min(os.get_terminal_size().columns, 80)
    print(f"{color}{char * width}{RST}")

def info(msg):   print(f"{C}ℹ {RST}{msg}")
def success(msg):print(f"{G}✓ {RST}{msg}")
def warn(msg):   print(f"{Y}⚠ {RST}{msg}")
def error(msg):  print(f"{R}✗ {RST}{msg}")
def agent(msg):
    hr()
    # Word-wrap long lines
    for line in msg.splitlines():
        if line.strip():
            wrapped = textwrap.fill(line, width=76, subsequent_indent="  ")
            print(f"  {wrapped}")
        else:
            print()
    hr()


# ── OLLAMA ───────────────────────────────────────────────────────────────────
def get_models():
    try:
        r = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=5)
        r.raise_for_status()
        return [m["name"] for m in r.json().get("models", [])]
    except requests.exceptions.ConnectionError:
        error("Cannot connect to Ollama. Make sure it is running.")
        sys.exit(1)

def pick_model(models):
    print(f"{BOLD}Available models:{RST}\n")
    for i, m in enumerate(models, 1):
        print(f"  {Y}{i:2}.{RST} {m}")
    print()
    while True:
        try:
            choice = input(f"{W}Pick a model (number): {RST}").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(models):
                return models[idx]
        except (ValueError, KeyboardInterrupt):
            pass
        warn("Invalid choice, try again.")

def chat_ollama(model, messages):
    """Send messages to Ollama, return full response text."""
    try:
        r = requests.post(
            f"{OLLAMA_BASE}/api/chat",
            json={"model": model, "messages": messages, "stream": True},
            stream=True,
            timeout=300,
        )
        full = ""
        print(f"\n{M}Agent:{RST} ", end="", flush=True)
        for line in r.iter_lines():
            if line:
                try:
                    chunk = json.loads(line)
                    content = chunk.get("message", {}).get("content", "")
                    print(content, end="", flush=True)
                    full += content
                    if chunk.get("done"):
                        break
                except json.JSONDecodeError:
                    continue
        print()
        return full
    except Exception as e:
        error(f"Ollama error: {e}")
        return ""


# ── PROJECT READING ──────────────────────────────────────────────────────────
def read_project_tree():
    """Return a string tree of the project files."""
    lines = [f"{PROJECT_DIR.name}/"]
    def walk(path, prefix=""):
        entries = sorted(path.iterdir(), key=lambda p: (p.is_file(), p.name))
        for i, entry in enumerate(entries):
            if entry.name in IGNORE_DIRS: continue
            if entry.suffix in IGNORE_EXTS: continue
            connector = "└── " if i == len(entries) - 1 else "├── "
            lines.append(f"{prefix}{connector}{entry.name}")
            if entry.is_dir():
                extension = "    " if i == len(entries) - 1 else "│   "
                walk(entry, prefix + extension)
    walk(PROJECT_DIR)
    return "\n".join(lines)

def read_file(path):
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
        if len(text) > MAX_FILE_SIZE:
            return text[:MAX_FILE_SIZE] + f"\n... [truncated at {MAX_FILE_SIZE} chars]"
        return text
    except Exception as e:
        return f"[Error reading file: {e}]"

def collect_context():
    """Read all text files in project into a context string."""
    parts = ["=== PROJECT STRUCTURE ===", read_project_tree(), ""]
    for p in sorted(PROJECT_DIR.rglob("*")):
        if not p.is_file(): continue
        if any(d in p.parts for d in IGNORE_DIRS): continue
        if p.suffix in IGNORE_EXTS: continue
        rel = p.relative_to(PROJECT_DIR)
        parts.append(f"=== FILE: {rel} ===")
        parts.append(read_file(p))
        parts.append("")
    return "\n".join(parts)


# ── ACTION PARSING ───────────────────────────────────────────────────────────
def parse_actions(response):
    """
    Extract structured actions from the model response.
    The model outputs actions in fenced blocks like:

    ```action
    ACTION: write_file
    PATH: src/app.py
    CONTENT:
    <file content here>
    ```

    or

    ```action
    ACTION: run_command
    COMMAND: pip install flask
    ```
    """
    actions = []
    lines = response.split("\n")
    in_block = False
    block_lines = []

    for line in lines:
        if line.strip() == "```action":
            in_block = True
            block_lines = []
        elif line.strip() == "```" and in_block:
            in_block = False
            action = parse_action_block("\n".join(block_lines))
            if action:
                actions.append(action)
        elif in_block:
            block_lines.append(line)

    return actions

def parse_action_block(block):
    lines = block.strip().splitlines()
    action = {}
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("ACTION:"):
            action["type"] = line.split(":", 1)[1].strip()
        elif line.startswith("PATH:"):
            action["path"] = line.split(":", 1)[1].strip()
        elif line.startswith("COMMAND:"):
            action["command"] = line.split(":", 1)[1].strip()
        elif line.startswith("CONTENT:"):
            # Everything after CONTENT: is the file content
            action["content"] = "\n".join(lines[i+1:])
            break
        i += 1
    return action if "type" in action else None


# ── APPROVAL ─────────────────────────────────────────────────────────────────
def ask_approval(action, always_approve):
    if always_approve:
        return True, True

    atype = action.get("type", "")
    print()

    if atype == "write_file":
        path = action.get("path", "?")
        content = action.get("content", "")
        print(f"{Y}Proposed action:{RST} Write file  {BOLD}{path}{RST}")
        hr("·", DIM)
        # Show a preview (first 20 lines)
        preview = "\n".join(content.splitlines()[:20])
        if len(content.splitlines()) > 20:
            preview += f"\n{DIM}... ({len(content.splitlines())} lines total){RST}"
        print(preview)

    elif atype == "run_command":
        cmd = action.get("command", "?")
        print(f"{Y}Proposed action:{RST} Run command")
        print(f"  {BOLD}{R}$ {cmd}{RST}")

    elif atype == "read_file":
        path = action.get("path", "?")
        print(f"{Y}Proposed action:{RST} Read file  {BOLD}{path}{RST}")

    print()
    print(f"  {G}y{RST} = yes   {G}a{RST} = always approve   {R}n{RST} = skip   {R}q{RST} = quit")
    print()

    while True:
        try:
            choice = input(f"{W}> {RST}").strip().lower()
        except KeyboardInterrupt:
            print()
            return False, False
        if choice == "y":
            return True, False
        elif choice == "a":
            success("Always-approve mode ON for this session.")
            return True, True
        elif choice == "n":
            warn("Skipped.")
            return False, False
        elif choice == "q":
            print(f"\n{Y}Goodbye!{RST}\n")
            sys.exit(0)


# ── ACTION EXECUTION ─────────────────────────────────────────────────────────
def execute_action(action):
    atype = action.get("type", "")

    if atype == "write_file":
        path = PROJECT_DIR / action.get("path", "")
        content = action.get("content", "")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        success(f"Written: {path.relative_to(PROJECT_DIR)}")
        return f"File written: {action.get('path')}"

    elif atype == "run_command":
        cmd = action.get("command", "")
        info(f"Running: {cmd}")
        result = subprocess.run(
            cmd, shell=True, cwd=PROJECT_DIR,
            capture_output=True, text=True, timeout=60
        )
        output = ""
        if result.stdout:
            print(result.stdout)
            output += result.stdout
        if result.stderr:
            print(f"{Y}{result.stderr}{RST}")
            output += result.stderr
        if result.returncode != 0:
            warn(f"Exit code: {result.returncode}")
        return f"Command output:\n{output}" if output else f"Command ran, exit code {result.returncode}"

    elif atype == "read_file":
        path = PROJECT_DIR / action.get("path", "")
        content = read_file(path)
        info(f"Read: {action.get('path')}")
        return f"File content of {action.get('path')}:\n{content}"

    else:
        warn(f"Unknown action type: {atype}")
        return f"Unknown action: {atype}"


# ── SYSTEM PROMPT ─────────────────────────────────────────────────────────────
def build_system_prompt(context):
    return f"""You are an expert coding agent running in a project directory. 
You help the user by reading, writing, and editing files and running shell commands.

When you need to take an action, output it in this exact format inside a fenced block:

To write or create a file:
```action
ACTION: write_file
PATH: relative/path/to/file.py
CONTENT:
<full file content here>
```

To run a shell command:
```action
ACTION: run_command
COMMAND: python -m pytest
```

To read a specific file:
```action
ACTION: read_file
PATH: relative/path/to/file.py
```

Rules:
- Always explain what you are doing and why BEFORE the action block
- You can output multiple action blocks in one response
- Write complete files, never partial snippets
- After actions are executed you will receive the results and can continue
- Be concise in explanations, thorough in code
- If a task is done, say so clearly with no action blocks

Here is the current project context:

{context}
"""


# ── MAIN LOOP ─────────────────────────────────────────────────────────────────
def main():
    clear()
    banner()

    # Pick model
    models = get_models()
    if not models:
        error("No models found. Pull a model with: ollama pull <model>")
        sys.exit(1)
    model = pick_model(models)
    success(f"Using model: {BOLD}{model}{RST}")
    print()

    # Load project context once at start
    info("Reading project files...")
    context = collect_context()
    success(f"Project loaded ({len(context):,} chars of context)")
    print()

    system_prompt = build_system_prompt(context)
    messages = [{"role": "system", "content": system_prompt}]
    always_approve = False

    hr("═", B)
    print(f"{DIM}Type your task. Type {RST}{W}exit{RST}{DIM} or {RST}{W}quit{RST}{DIM} to leave.{RST}")
    print(f"{DIM}Type {RST}{W}reload{RST}{DIM} to re-read project files.{RST}")
    hr("═", B)
    print()

    while True:
        try:
            task = input(f"{G}{BOLD}You:{RST} ").strip()
        except KeyboardInterrupt:
            print(f"\n{Y}Goodbye!{RST}\n")
            break

        if not task:
            continue
        if task.lower() in ("exit", "quit"):
            print(f"\n{Y}Goodbye!{RST}\n")
            break
        if task.lower() == "reload":
            info("Reloading project files...")
            context = collect_context()
            system_prompt = build_system_prompt(context)
            messages = [{"role": "system", "content": system_prompt}]
            success(f"Reloaded ({len(context):,} chars)")
            continue

        messages.append({"role": "user", "content": task})

        # Agent loop — keeps going until no more actions
        iteration = 0
        while True:
            iteration += 1
            response = chat_ollama(model, messages)
            if not response:
                break

            messages.append({"role": "assistant", "content": response})

            actions = parse_actions(response)
            if not actions:
                # No actions — agent is done with this task
                break

            action_results = []
            for action in actions:
                approved, always_approve = ask_approval(action, always_approve)
                if approved:
                    result = execute_action(action)
                    action_results.append(result)
                else:
                    action_results.append(f"Action skipped by user: {action.get('type')}")

            # Feed results back to the model
            results_msg = "Action results:\n" + "\n\n".join(action_results)
            messages.append({"role": "user", "content": results_msg})

            # Safety limit
            if iteration >= 20:
                warn("Reached 20 iterations, stopping to avoid infinite loop.")
                break

        print()


if __name__ == "__main__":
    main()
